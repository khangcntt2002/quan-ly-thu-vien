const express = require('express')
const app = express()
const path = require('path');
const books = require('./data/books.json');

const multer = require('multer');
// Cấu hình multer / configuration for multer
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, path.join(__dirname, '/uploads'))
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname)
    }
});
const upload = multer({ storage: storage });
// Middleware để phân tích dữ liệu từ form
app.use(express.urlencoded({ extended: false }));
// Middleware cho static files (CSS, JS, hình ảnh)
app.use(express.static(path.join(__dirname, 'public')));

// Cấu hình view engine là Pug
app.set('view engine' , 'pug');
app.set('views' , path.join(__dirname, 'views'));


app.use((req, res, next) => {
    console.log('Date: ', Date.now());
    next();
});

const userRoute = require('./routes/userRoute');
app.use('/user', userRoute);


app.get('/books', (req, res) => {
    res.render('books', { title: 'Danh sách sách', books, activePage: 'books' });
});

app.get('/books/:id', (req, res) => {
    const book = books.find(book => book.id === req.params.id);
    if (!book) {
        return res.status(404).render('error', {
            title: 'Không tìm thấy sách',
            status: 404,
            message: 'Không tìm thấy sách bạn yêu cầu.',
            activePage: 'books'
        });
    }
    res.render('book-detail', { title: book.title, book, activePage: 'books' });
});

app.get('/login', (req, res) => {
    res.render('login', { title: 'Login'})
});

app.post('/login', (req, res) => {
    if (!req.body) {
        return res.status(400).send('Dữ liệu không hợp lệ');
    }
    if (!req.body.username || !req.body.password) {
        return res.status(400).send('Vui lòng nhập đầy đủ thông tin đăng nhập');
    }

    const {username, password} = req.body;
    // Xử lý đăng nhập ở đây
    if (username === 'admin' && password === 'admin') {
        return res.send('Đăng nhập thành công');
    } else {
        return res.send('Đăng nhập thất bại');
    }
});

app.get('/register', (req, res) => {
    res.render('register', { title: 'Register' });
});

app.post('/register', (req, res) => {
    if (!req.body) {
        return res.status(400).send('Dữ liệu không hợp lệ');
    }
    if (!req.body.username || !req.body.password || !req.body.email) {
        return res.status(400).send('Vui lòng nhập đầy đủ thông tin đăng ký');
    }

    const {username, password, email} = req.body;
    //console.log(`Username: ${username}, Password: ${password}, Email: ${email}`);
    // Xử lý đăng ký ở đây
    return res.send('Đăng ký thành công');
});

app.get('/', (req, res) => {
    res.render('index', { title: 'Trang chủ' });
});

app.use((req,res) => {
    res.status(404).render('error');
});

app.listen(4000, () => {
    console.log('Server is running on port 4000');
});
