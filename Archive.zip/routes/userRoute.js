const express = require('express');
const router = express.Router();

userlist = [
    {id: 1, name: 'Nguyen Van A', email: 'nguyenvana@example.com'},
    {id: 2, name: 'Tran Thi B', email: 'tranthib@example.com'},
    {id: 3, name: 'Le Van C', email: 'levanc@example.com'}
];  

router.get('/', (req, res) => {
    res.render('user',{ title: 'User List', userlist: userlist });
});

// api: localhost:3000/user/getAll
router.get('/getAll', (req, res) => {
    // query cơ sở dữ liệu
    res.json(userlist);
});

// localhost:3000/user/getById/1
router.get('/getById/:id', (req, res) => {
    const userId = parseInt(req.params.id);
    // đi query dữ liệu từ cơ sở dữ liệu
    const user = userlist.find(u => u.id === userId);
    if (!user) {
        return res.status(404).send('Người dùng không tồn tại');
    }
    res.json(user);
});

// localhost:4000/user/getID?userId=1
router.get('/getID', (req, res) => {
    if (!req.query)
            return res.status(404).send('không có query');
    const userId = parseInt(req.query.userId);
    // đi query dữ liệu từ cơ sở dữ liệu
    const user = userlist.find(u => u.id === userId);
    if (!user) {
        return res.status(404).send('Người dùng không tồn tại');
    }
    res.json(user);
});



router.post('/add', (req, res) => {
    if (!req.body)
    {
        return res.status(400).send('Dữ liệu không hợp lệ');
    }
    if (!req.body.username || !req.body.password || !req.body.email) {
        return res.status(400).send('Vui lòng nhập đầy đủ thông tin đăng ký');
    }

    const {username, password, email} = req.body;
    // add lên cơ sở dữ liệu ở đây

    return res.status(200).send('Đăng ký thành công');
});


module.exports = router;